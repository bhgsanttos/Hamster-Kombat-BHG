#!/bin/bash

# Script de Deploy do WhatsApp Expense Bot
# Autor: Manus AI
# Data: $(date)

set -e  # Parar em caso de erro

echo "🚀 Iniciando deploy do WhatsApp Expense Bot..."

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log colorido
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar se está no diretório correto
if [ ! -f "src/main.py" ]; then
    log_error "Arquivo src/main.py não encontrado. Execute este script no diretório raiz do projeto."
    exit 1
fi

# Verificar Python
log_info "Verificando Python..."
if ! command -v python3.11 &> /dev/null; then
    log_error "Python 3.11 não encontrado. Instale Python 3.11 primeiro."
    exit 1
fi
log_success "Python 3.11 encontrado"

# Verificar ambiente virtual
log_info "Verificando ambiente virtual..."
if [ ! -d "venv" ]; then
    log_warning "Ambiente virtual não encontrado. Criando..."
    python3.11 -m venv venv
fi
log_success "Ambiente virtual OK"

# Ativar ambiente virtual
log_info "Ativando ambiente virtual..."
source venv/bin/activate

# Atualizar pip
log_info "Atualizando pip..."
pip install --upgrade pip

# Instalar dependências
log_info "Instalando dependências..."
pip install -r requirements.txt

# Verificar variáveis de ambiente
log_info "Verificando configurações..."
if [ ! -f ".env" ]; then
    log_warning "Arquivo .env não encontrado. Copiando exemplo..."
    cp .env.example .env
    log_warning "IMPORTANTE: Configure as variáveis em .env antes de continuar!"
fi

# Verificar configurações obrigatórias
if [ -z "$WHATSAPP_ACCESS_TOKEN" ] && [ -z "$(grep WHATSAPP_ACCESS_TOKEN .env | cut -d'=' -f2)" ]; then
    log_error "WHATSAPP_ACCESS_TOKEN não configurado!"
    log_info "Configure as variáveis em .env e execute novamente."
    exit 1
fi

# Criar diretórios necessários
log_info "Criando diretórios..."
mkdir -p logs
mkdir -p backups
mkdir -p tmp

# Verificar banco de dados
log_info "Verificando banco de dados..."
if [ ! -f "src/database/app.db" ]; then
    log_info "Criando banco de dados..."
    python -c "
from src.main import app
from src.models.user import db
from src.models.expense import Expense
with app.app_context():
    db.create_all()
    print('Banco de dados criado com sucesso!')
"
fi
log_success "Banco de dados OK"

# Testar aplicação
log_info "Testando aplicação..."
python -c "
import sys
sys.path.insert(0, '.')
from src.main import app
print('Teste de importação: OK')
"
log_success "Aplicação testada com sucesso"

# Opções de deploy
echo ""
log_info "Escolha o tipo de deploy:"
echo "1) Desenvolvimento (Flask dev server)"
echo "2) Produção local (Gunicorn)"
echo "3) Deploy automático (serviço integrado)"
echo "4) Apenas preparar (não executar)"

read -p "Opção [1-4]: " deploy_option

case $deploy_option in
    1)
        log_info "Iniciando servidor de desenvolvimento..."
        export FLASK_ENV=development
        export FLASK_DEBUG=True
        python src/main.py
        ;;
    2)
        log_info "Instalando Gunicorn..."
        pip install gunicorn
        log_info "Iniciando servidor de produção..."
        gunicorn -w 4 -b 0.0.0.0:5000 --timeout 120 --access-logfile logs/access.log --error-logfile logs/error.log src.main:app
        ;;
    3)
        log_info "Preparando para deploy automático..."
        # Aqui seria chamado o serviço de deploy integrado
        log_success "Sistema preparado para deploy automático"
        log_info "Use o comando de deploy do sistema para publicar"
        ;;
    4)
        log_success "Sistema preparado com sucesso!"
        log_info "Para executar manualmente:"
        log_info "  Desenvolvimento: python src/main.py"
        log_info "  Produção: gunicorn -w 4 -b 0.0.0.0:5000 src.main:app"
        ;;
    *)
        log_error "Opção inválida"
        exit 1
        ;;
esac

log_success "Deploy concluído!"
echo ""
log_info "Próximos passos:"
echo "1. Configure o webhook no Meta for Developers"
echo "2. Teste enviando uma mensagem para o WhatsApp"
echo "3. Monitore os logs em logs/app.log"
echo ""
log_info "URLs importantes:"
echo "- Interface web: http://localhost:5000"
echo "- Webhook: http://seu-dominio.com/api/whatsapp/webhook"
echo "- API docs: http://localhost:5000/api"

