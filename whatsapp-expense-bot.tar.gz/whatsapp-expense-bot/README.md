# 🤖 WhatsApp Expense Bot

## Assistente Virtual Inteligente para Controle de Gastos via WhatsApp

O WhatsApp Expense Bot é um sistema completo que permite aos usuários registrar seus gastos através de mensagens de texto ou áudio enviadas pelo WhatsApp. O sistema utiliza inteligência artificial para processar as mensagens, extrair informações de gastos e manter uma planilha atualizada automaticamente.

## 🚀 Funcionalidades Principais

### 🎤 Processamento de Áudio
- Recebe mensagens de voz pelo WhatsApp
- Transcreve áudio usando OpenAI Whisper
- Extrai informações de gastos da transcrição
- Suporte a diferentes formatos de áudio

### 💬 Processamento de Texto
- Processa mensagens de texto em linguagem natural
- Reconhece padrões como "Gastei R$ 50 no supermercado"
- Extração inteligente de valores, descrições e categorias
- Suporte a diferentes formas de expressar gastos

### 🏷️ Categorização Automática
- Categoriza gastos automaticamente usando IA
- Categorias: Alimentação, Transporte, Saúde, Lazer, Casa, Roupas, Outros
- Aprendizado baseado em palavras-chave e contexto
- Possibilidade de recategorização manual

### 📊 Geração de Planilhas
- Gera planilhas Excel automaticamente
- Organização por data, categoria e valor
- Resumos e totais automáticos
- Gráficos e análises por categoria
- Relatórios mensais personalizados

### ✅ Confirmações Inteligentes
- Confirma cada gasto registrado via WhatsApp
- Mensagens de erro amigáveis
- Sugestões de correção quando necessário
- Feedback em tempo real

## 🏗️ Arquitetura do Sistema

### Backend (Flask)
- **Framework**: Flask com Python 3.11
- **Banco de Dados**: SQLite com SQLAlchemy
- **APIs**: WhatsApp Business API, OpenAI API
- **Processamento**: Whisper para áudio, GPT para texto

### Estrutura de Pastas
```
whatsapp-expense-bot/
├── src/
│   ├── models/          # Modelos de dados
│   │   ├── user.py      # Modelo de usuário
│   │   └── expense.py   # Modelo de gastos
│   ├── routes/          # Rotas da API
│   │   ├── user.py      # Rotas de usuário
│   │   └── whatsapp.py  # Webhook do WhatsApp
│   ├── services/        # Serviços de negócio
│   │   ├── ai_processor.py        # Processamento IA
│   │   ├── audio_processor.py     # Processamento áudio
│   │   ├── whatsapp_client.py     # Cliente WhatsApp
│   │   └── spreadsheet_generator.py # Geração planilhas
│   ├── static/          # Arquivos estáticos
│   │   └── index.html   # Interface web
│   ├── database/        # Banco de dados
│   │   └── app.db       # SQLite database
│   └── main.py          # Arquivo principal
├── venv/                # Ambiente virtual
├── requirements.txt     # Dependências
└── README.md           # Documentação
```

## 🔧 Configuração e Instalação

### Pré-requisitos
- Python 3.11+
- Conta no Meta for Developers
- Conta OpenAI (já configurada)
- WhatsApp Business API

### 1. Clonagem e Configuração
```bash
# Clonar o repositório
git clone <repository-url>
cd whatsapp-expense-bot

# Ativar ambiente virtual
source venv/bin/activate

# Instalar dependências
pip install -r requirements.txt
```

### 2. Configuração do WhatsApp Business API

#### 2.1 Criar Aplicação no Meta for Developers
1. Acesse [Meta for Developers](https://developers.facebook.com/)
2. Crie uma nova aplicação
3. Adicione o produto "WhatsApp Business"
4. Configure o número de telefone

#### 2.2 Obter Tokens de Acesso
- **Access Token**: Token de acesso permanente
- **Phone Number ID**: ID do número de telefone
- **Verify Token**: Token para verificação do webhook

#### 2.3 Configurar Webhook
- **URL**: `https://seu-dominio.com/api/whatsapp/webhook`
- **Verify Token**: Token definido na aplicação
- **Campos**: `messages`

### 3. Variáveis de Ambiente
```bash
export WHATSAPP_ACCESS_TOKEN="seu_token_aqui"
export WHATSAPP_PHONE_NUMBER_ID="seu_phone_number_id"
export OPENAI_API_KEY="já_configurado"
```

### 4. Executar Aplicação
```bash
# Desenvolvimento
python src/main.py

# Produção (recomendado usar gunicorn)
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

## 📡 API Endpoints

### Webhook do WhatsApp
- **GET** `/api/whatsapp/webhook` - Verificação do webhook
- **POST** `/api/whatsapp/webhook` - Receber mensagens

### Gestão de Gastos
- **GET** `/api/whatsapp/expenses/{phone}` - Listar gastos de usuário
- **GET** `/api/whatsapp/expenses/export/{phone}` - Exportar planilha

### Exemplos de Uso

#### Verificação do Webhook
```bash
curl "https://seu-dominio.com/api/whatsapp/webhook?hub.verify_token=meu_token_secreto_123&hub.challenge=teste"
```

#### Listar Gastos
```bash
curl "https://seu-dominio.com/api/whatsapp/expenses/5511999999999"
```

## 🤖 Processamento de IA

### Extração de Gastos
O sistema utiliza duas abordagens para extrair informações:

#### 1. Regex (Casos Simples)
- Padrões como "R$ 50", "50 reais", "gastei 50"
- Rápido e eficiente para casos comuns
- Fallback para IA em casos complexos

#### 2. OpenAI GPT (Casos Complexos)
- Processamento de linguagem natural avançado
- Compreensão de contexto e intenção
- Extração de valor, descrição e categoria

### Exemplos de Mensagens Suportadas
```
"Gastei R$ 50 no supermercado"
"Paguei 25 reais no Uber"
"Comprei uma pizza por R$ 35"
"Fui ao médico e custou 120"
"Abasteci o carro com 80 reais"
```

### Categorização Automática
- **Alimentação**: supermercado, restaurante, pizza, café
- **Transporte**: uber, taxi, gasolina, ônibus
- **Saúde**: médico, farmácia, remédio, consulta
- **Lazer**: cinema, bar, festa, show
- **Casa**: aluguel, luz, água, internet
- **Roupas**: camisa, sapato, loja de roupas

## 📊 Geração de Planilhas

### Funcionalidades da Planilha
- **Aba Principal**: Lista completa de gastos
- **Aba Resumo**: Totais por categoria
- **Formatação**: Cores, bordas, formatação monetária
- **Totais**: Soma automática de valores
- **Percentuais**: Distribuição por categoria

### Estrutura da Planilha
| Data | Descrição | Categoria | Valor (R$) | Data de Registro |
|------|-----------|-----------|------------|------------------|
| 01/08/2025 | Supermercado | Alimentação | R$ 50,00 | 01/08/2025 10:30 |
| 02/08/2025 | Uber | Transporte | R$ 25,00 | 02/08/2025 14:15 |

## 🔒 Segurança e Privacidade

### Proteção de Dados
- Dados armazenados localmente no SQLite
- Tokens de acesso em variáveis de ambiente
- Validação de webhook com verify token
- HTTPS obrigatório em produção

### Boas Práticas
- Logs de auditoria para todas as operações
- Validação de entrada em todos os endpoints
- Rate limiting para prevenir spam
- Backup regular do banco de dados

## 🚀 Deploy em Produção

### Opção 1: Deploy Automático
```bash
# O sistema pode ser deployado automaticamente
# usando o serviço de deploy integrado
```

### Opção 2: Deploy Manual

#### Usando Gunicorn
```bash
# Instalar gunicorn
pip install gunicorn

# Executar em produção
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

#### Usando Docker
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY . .

RUN pip install -r requirements.txt

EXPOSE 5000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "src.main:app"]
```

### Configuração de Proxy Reverso (Nginx)
```nginx
server {
    listen 80;
    server_name seu-dominio.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 📱 Como Usar

### 1. Configuração Inicial
- Configure o webhook no Meta for Developers
- Defina as variáveis de ambiente
- Inicie o servidor

### 2. Envio de Gastos
- Envie mensagem de texto: "Gastei R$ 50 no supermercado"
- Ou envie áudio descrevendo o gasto
- Receba confirmação automática

### 3. Geração de Planilhas
- Solicite planilha via endpoint
- Ou implemente comando no WhatsApp
- Receba arquivo Excel por email/download

## 🔧 Personalização

### Adicionando Novas Categorias
```python
# Em ai_processor.py
categories = {
    'Nova Categoria': ['palavra1', 'palavra2', 'palavra3']
}
```

### Modificando Respostas
```python
# Em whatsapp.py
confirmation_msg = f"✅ Gasto registrado!\n\n💰 Valor: R$ {amount:.2f}"
```

### Adicionando Comandos
```python
# Exemplo: comando para relatório mensal
if text.lower() == '/relatorio':
    generate_monthly_report(phone_number)
```

## 🐛 Troubleshooting

### Problemas Comuns

#### Webhook não recebe mensagens
- Verificar URL do webhook
- Confirmar verify token
- Checar logs do servidor

#### IA não extrai gastos
- Verificar API key do OpenAI
- Testar com mensagens mais simples
- Verificar logs de erro

#### Planilhas não são geradas
- Verificar permissões de escrita
- Confirmar dependências instaladas
- Checar espaço em disco

### Logs e Monitoramento
```python
# Configurar logging detalhado
import logging
logging.basicConfig(level=logging.INFO)
```

## 🤝 Contribuição

### Como Contribuir
1. Fork do repositório
2. Criar branch para feature
3. Implementar mudanças
4. Testes unitários
5. Pull request

### Estrutura de Testes
```bash
# Executar testes
python -m pytest tests/

# Cobertura de código
coverage run -m pytest
coverage report
```

## 📄 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo LICENSE para detalhes.

## 🆘 Suporte

Para suporte técnico:
- Abra uma issue no GitHub
- Consulte a documentação da API
- Verifique os logs de erro

## 🔄 Atualizações Futuras

### Roadmap
- [ ] Interface web para gestão
- [ ] Relatórios avançados com gráficos
- [ ] Integração com bancos
- [ ] App mobile nativo
- [ ] Múltiplos usuários por conta
- [ ] Backup automático na nuvem

---

**Desenvolvido com ❤️ usando Flask, OpenAI e WhatsApp Business API**

