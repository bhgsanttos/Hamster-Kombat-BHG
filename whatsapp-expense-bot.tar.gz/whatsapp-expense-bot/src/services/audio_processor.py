import openai
import requests
import os
import tempfile
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Token de acesso do WhatsApp Business API (deve ser configurado)
WHATSAPP_ACCESS_TOKEN = os.getenv('WHATSAPP_ACCESS_TOKEN', 'seu_token_aqui')

def transcribe_audio(audio_id: str) -> Optional[str]:
    """
    Baixar áudio do WhatsApp e transcrever usando OpenAI Whisper
    
    Args:
        audio_id: ID do áudio no WhatsApp
        
    Returns:
        Texto transcrito ou None se houver erro
    """
    try:
        # Baixar áudio do WhatsApp
        audio_file_path = download_whatsapp_audio(audio_id)
        if not audio_file_path:
            return None
        
        # Transcrever usando OpenAI Whisper
        transcription = transcribe_with_whisper(audio_file_path)
        
        # Limpar arquivo temporário
        try:
            os.remove(audio_file_path)
        except:
            pass
        
        return transcription
    
    except Exception as e:
        logger.error(f"Erro ao transcrever áudio: {str(e)}")
        return None

def download_whatsapp_audio(audio_id: str) -> Optional[str]:
    """
    Baixar arquivo de áudio do WhatsApp usando a API
    """
    try:
        # Primeiro, obter URL do arquivo
        media_url_response = requests.get(
            f"https://graph.facebook.com/v18.0/{audio_id}",
            headers={
                'Authorization': f'Bearer {WHATSAPP_ACCESS_TOKEN}'
            }
        )
        
        if media_url_response.status_code != 200:
            logger.error(f"Erro ao obter URL do áudio: {media_url_response.text}")
            return None
        
        media_data = media_url_response.json()
        audio_url = media_data.get('url')
        
        if not audio_url:
            logger.error("URL do áudio não encontrada")
            return None
        
        # Baixar o arquivo de áudio
        audio_response = requests.get(
            audio_url,
            headers={
                'Authorization': f'Bearer {WHATSAPP_ACCESS_TOKEN}'
            }
        )
        
        if audio_response.status_code != 200:
            logger.error(f"Erro ao baixar áudio: {audio_response.status_code}")
            return None
        
        # Salvar em arquivo temporário
        with tempfile.NamedTemporaryFile(delete=False, suffix='.ogg') as temp_file:
            temp_file.write(audio_response.content)
            return temp_file.name
    
    except Exception as e:
        logger.error(f"Erro ao baixar áudio do WhatsApp: {str(e)}")
        return None

def transcribe_with_whisper(audio_file_path: str) -> Optional[str]:
    """
    Transcrever áudio usando OpenAI Whisper
    """
    try:
        client = openai.OpenAI()
        
        with open(audio_file_path, 'rb') as audio_file:
            transcription = client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file,
                language="pt"  # Português
            )
        
        return transcription.text.strip()
    
    except Exception as e:
        logger.error(f"Erro na transcrição com Whisper: {str(e)}")
        return None

def convert_audio_format(input_path: str, output_path: str) -> bool:
    """
    Converter formato de áudio se necessário (usando ffmpeg se disponível)
    """
    try:
        import subprocess
        
        # Tentar converter usando ffmpeg
        result = subprocess.run([
            'ffmpeg', '-i', input_path, '-acodec', 'libmp3lame', output_path
        ], capture_output=True, text=True)
        
        return result.returncode == 0
    
    except Exception as e:
        logger.error(f"Erro na conversão de áudio: {str(e)}")
        return False

def validate_audio_file(file_path: str) -> bool:
    """
    Validar se o arquivo de áudio é válido
    """
    try:
        # Verificar se arquivo existe e tem tamanho > 0
        if not os.path.exists(file_path):
            return False
        
        if os.path.getsize(file_path) == 0:
            return False
        
        # Verificar extensão
        valid_extensions = ['.mp3', '.wav', '.ogg', '.m4a', '.flac']
        file_ext = os.path.splitext(file_path)[1].lower()
        
        return file_ext in valid_extensions
    
    except Exception as e:
        logger.error(f"Erro na validação do áudio: {str(e)}")
        return False

