import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime
import os
import logging
from typing import List
from src.models.expense import Expense

logger = logging.getLogger(__name__)

def generate_expense_spreadsheet(expenses: List[Expense], user_phone: str) -> str:
    """
    Gerar planilha Excel com os gastos do usuário
    
    Args:
        expenses: Lista de gastos
        user_phone: Telefone do usuário
        
    Returns:
        Caminho do arquivo gerado
    """
    try:
        # Criar workbook
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Meus Gastos"
        
        # Configurar estilos
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # Cabeçalhos
        headers = ["Data", "Descrição", "Categoria", "Valor (R$)", "Data de Registro"]
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = border
        
        # Dados dos gastos
        total_amount = 0
        for row, expense in enumerate(expenses, 2):
            # Data do gasto
            date_str = expense.date.strftime("%d/%m/%Y") if expense.date else ""
            ws.cell(row=row, column=1, value=date_str).border = border
            
            # Descrição
            ws.cell(row=row, column=2, value=expense.description).border = border
            
            # Categoria
            ws.cell(row=row, column=3, value=expense.category or "Não categorizado").border = border
            
            # Valor
            amount_cell = ws.cell(row=row, column=4, value=expense.amount)
            amount_cell.number_format = 'R$ #,##0.00'
            amount_cell.border = border
            total_amount += expense.amount
            
            # Data de registro
            created_str = expense.created_at.strftime("%d/%m/%Y %H:%M") if expense.created_at else ""
            ws.cell(row=row, column=5, value=created_str).border = border
        
        # Linha de total
        if expenses:
            total_row = len(expenses) + 2
            ws.cell(row=total_row, column=3, value="TOTAL:").font = Font(bold=True)
            total_cell = ws.cell(row=total_row, column=4, value=total_amount)
            total_cell.font = Font(bold=True)
            total_cell.number_format = 'R$ #,##0.00'
            total_cell.fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
        
        # Ajustar largura das colunas
        column_widths = [12, 30, 15, 15, 20]
        for col, width in enumerate(column_widths, 1):
            ws.column_dimensions[get_column_letter(col)].width = width
        
        # Adicionar resumo por categoria
        add_category_summary(wb, expenses)
        
        # Salvar arquivo
        filename = f"gastos_{user_phone.replace('+', '')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        filepath = os.path.join("/tmp", filename)
        wb.save(filepath)
        
        logger.info(f"Planilha gerada: {filepath}")
        return filepath
    
    except Exception as e:
        logger.error(f"Erro ao gerar planilha: {str(e)}")
        raise

def add_category_summary(wb, expenses: List[Expense]):
    """
    Adicionar aba com resumo por categoria
    """
    try:
        # Criar nova aba
        ws_summary = wb.create_sheet("Resumo por Categoria")
        
        # Calcular totais por categoria
        category_totals = {}
        for expense in expenses:
            category = expense.category or "Não categorizado"
            category_totals[category] = category_totals.get(category, 0) + expense.amount
        
        # Estilos
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # Cabeçalhos
        ws_summary.cell(row=1, column=1, value="Categoria").font = header_font
        ws_summary.cell(row=1, column=1).fill = header_fill
        ws_summary.cell(row=1, column=1).border = border
        
        ws_summary.cell(row=1, column=2, value="Total (R$)").font = header_font
        ws_summary.cell(row=1, column=2).fill = header_fill
        ws_summary.cell(row=1, column=2).border = border
        
        ws_summary.cell(row=1, column=3, value="Percentual").font = header_font
        ws_summary.cell(row=1, column=3).fill = header_fill
        ws_summary.cell(row=1, column=3).border = border
        
        # Dados
        total_geral = sum(category_totals.values())
        row = 2
        for category, total in sorted(category_totals.items(), key=lambda x: x[1], reverse=True):
            ws_summary.cell(row=row, column=1, value=category).border = border
            
            amount_cell = ws_summary.cell(row=row, column=2, value=total)
            amount_cell.number_format = 'R$ #,##0.00'
            amount_cell.border = border
            
            percentage = (total / total_geral * 100) if total_geral > 0 else 0
            percent_cell = ws_summary.cell(row=row, column=3, value=percentage/100)
            percent_cell.number_format = '0.0%'
            percent_cell.border = border
            
            row += 1
        
        # Ajustar largura das colunas
        ws_summary.column_dimensions['A'].width = 20
        ws_summary.column_dimensions['B'].width = 15
        ws_summary.column_dimensions['C'].width = 12
        
    except Exception as e:
        logger.error(f"Erro ao criar resumo por categoria: {str(e)}")

def generate_monthly_report(user_phone: str, year: int, month: int) -> str:
    """
    Gerar relatório mensal de gastos
    
    Args:
        user_phone: Telefone do usuário
        year: Ano
        month: Mês
        
    Returns:
        Caminho do arquivo gerado
    """
    try:
        from src.models.expense import Expense
        from sqlalchemy import and_, extract
        
        # Buscar gastos do mês
        expenses = Expense.query.filter(
            and_(
                Expense.user_phone == user_phone,
                extract('year', Expense.date) == year,
                extract('month', Expense.date) == month
            )
        ).order_by(Expense.date.desc()).all()
        
        if not expenses:
            logger.warning(f"Nenhum gasto encontrado para {month}/{year}")
            return None
        
        # Gerar planilha
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = f"Gastos {month:02d}/{year}"
        
        # Título
        title_cell = ws.cell(row=1, column=1, value=f"Relatório de Gastos - {month:02d}/{year}")
        title_cell.font = Font(size=16, bold=True)
        ws.merge_cells('A1:E1')
        
        # Cabeçalhos (linha 3)
        headers = ["Data", "Descrição", "Categoria", "Valor (R$)"]
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col, value=header)
            cell.font = Font(bold=True)
        
        # Dados
        total = 0
        for row, expense in enumerate(expenses, 4):
            ws.cell(row=row, column=1, value=expense.date.strftime("%d/%m/%Y"))
            ws.cell(row=row, column=2, value=expense.description)
            ws.cell(row=row, column=3, value=expense.category or "Não categorizado")
            
            amount_cell = ws.cell(row=row, column=4, value=expense.amount)
            amount_cell.number_format = 'R$ #,##0.00'
            total += expense.amount
        
        # Total
        total_row = len(expenses) + 4
        ws.cell(row=total_row, column=3, value="TOTAL:").font = Font(bold=True)
        total_cell = ws.cell(row=total_row, column=4, value=total)
        total_cell.font = Font(bold=True)
        total_cell.number_format = 'R$ #,##0.00'
        
        # Salvar
        filename = f"relatorio_{user_phone.replace('+', '')}_{year}{month:02d}.xlsx"
        filepath = os.path.join("/tmp", filename)
        wb.save(filepath)
        
        return filepath
    
    except Exception as e:
        logger.error(f"Erro ao gerar relatório mensal: {str(e)}")
        raise

def create_expense_chart_data(expenses: List[Expense]) -> dict:
    """
    Preparar dados para gráficos de gastos
    
    Args:
        expenses: Lista de gastos
        
    Returns:
        Dicionário com dados para gráficos
    """
    try:
        # Gastos por categoria
        category_data = {}
        for expense in expenses:
            category = expense.category or "Não categorizado"
            category_data[category] = category_data.get(category, 0) + expense.amount
        
        # Gastos por mês
        monthly_data = {}
        for expense in expenses:
            if expense.date:
                month_key = expense.date.strftime("%Y-%m")
                monthly_data[month_key] = monthly_data.get(month_key, 0) + expense.amount
        
        # Gastos por dia da semana
        weekday_data = {
            'Segunda': 0, 'Terça': 0, 'Quarta': 0, 'Quinta': 0,
            'Sexta': 0, 'Sábado': 0, 'Domingo': 0
        }
        weekday_names = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
        
        for expense in expenses:
            if expense.date:
                weekday = weekday_names[expense.date.weekday()]
                weekday_data[weekday] += expense.amount
        
        return {
            'categories': category_data,
            'monthly': monthly_data,
            'weekdays': weekday_data,
            'total': sum(expense.amount for expense in expenses),
            'count': len(expenses)
        }
    
    except Exception as e:
        logger.error(f"Erro ao preparar dados do gráfico: {str(e)}")
        return {}

