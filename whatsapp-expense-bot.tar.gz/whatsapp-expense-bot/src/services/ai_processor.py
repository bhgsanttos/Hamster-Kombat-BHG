import openai
import json
import re
import logging
from typing import Optional, Dict

logger = logging.getLogger(__name__)

def process_expense_message(text: str) -> Optional[Dict]:
    """
    Processar mensagem de texto para extrair informações de gasto usando OpenAI
    
    Args:
        text: Texto da mensagem do usuário
        
    Returns:
        Dict com informações do gasto ou None se não conseguir extrair
    """
    try:
        # Primeiro tentar extrair com regex simples
        simple_result = extract_expense_with_regex(text)
        if simple_result:
            return simple_result
        
        # Se regex não funcionar, usar OpenAI
        return extract_expense_with_ai(text)
    
    except Exception as e:
        logger.error(f"Erro ao processar mensagem: {str(e)}")
        return None

def extract_expense_with_regex(text: str) -> Optional[Dict]:
    """
    Tentar extrair gasto usando regex para casos simples
    """
    try:
        # Padrões comuns para valores em reais
        money_patterns = [
            r'R\$\s*(\d+(?:,\d{2})?)',  # R$ 50,00 ou R$ 50
            r'(\d+(?:,\d{2})?)\s*reais?',  # 50 reais
            r'gastei\s+(\d+(?:,\d{2})?)',  # gastei 50
            r'paguei\s+(\d+(?:,\d{2})?)',  # paguei 50
            r'comprei.*?(\d+(?:,\d{2})?)',  # comprei por 50
        ]
        
        amount = None
        for pattern in money_patterns:
            match = re.search(pattern, text.lower())
            if match:
                amount_str = match.group(1).replace(',', '.')
                amount = float(amount_str)
                break
        
        if amount is None:
            return None
        
        # Extrair descrição (remover valor e palavras comuns)
        description = text
        for pattern in money_patterns:
            description = re.sub(pattern, '', description, flags=re.IGNORECASE)
        
        # Limpar descrição
        description = re.sub(r'\b(gastei|paguei|comprei|por|reais?|r\$)\b', '', description, flags=re.IGNORECASE)
        description = re.sub(r'\s+', ' ', description).strip()
        
        if not description:
            description = "Gasto não especificado"
        
        # Tentar identificar categoria básica
        category = identify_basic_category(text)
        
        return {
            'amount': amount,
            'description': description,
            'category': category
        }
    
    except Exception as e:
        logger.error(f"Erro no regex: {str(e)}")
        return None

def identify_basic_category(text: str) -> Optional[str]:
    """
    Identificar categoria básica baseada em palavras-chave
    """
    text_lower = text.lower()
    
    categories = {
        'Alimentação': ['supermercado', 'mercado', 'comida', 'restaurante', 'lanche', 'pizza', 'hambúrguer', 'café', 'padaria'],
        'Transporte': ['uber', 'taxi', 'ônibus', 'metrô', 'gasolina', 'combustível', 'estacionamento'],
        'Saúde': ['farmácia', 'remédio', 'médico', 'consulta', 'exame', 'hospital'],
        'Lazer': ['cinema', 'teatro', 'show', 'festa', 'bar', 'balada', 'jogo'],
        'Casa': ['casa', 'apartamento', 'aluguel', 'condomínio', 'luz', 'água', 'internet'],
        'Roupas': ['roupa', 'camisa', 'calça', 'sapato', 'tênis', 'vestido', 'loja']
    }
    
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in text_lower:
                return category
    
    return None

def extract_expense_with_ai(text: str) -> Optional[Dict]:
    """
    Usar OpenAI para extrair informações de gasto de texto complexo
    """
    try:
        client = openai.OpenAI()
        
        prompt = f"""
        Analise a seguinte mensagem e extraia informações de gasto/compra:
        
        Mensagem: "{text}"
        
        Extraia as seguintes informações:
        1. Valor gasto (em reais, apenas o número)
        2. Descrição do que foi comprado/gasto
        3. Categoria (Alimentação, Transporte, Saúde, Lazer, Casa, Roupas, Outros)
        
        Responda APENAS com um JSON válido no formato:
        {{"amount": 0.0, "description": "descrição", "category": "categoria"}}
        
        Se não conseguir identificar um gasto válido, responda: null
        """
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Você é um assistente especializado em extrair informações de gastos de mensagens em português brasileiro."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=150,
            temperature=0.1
        )
        
        result_text = response.choices[0].message.content.strip()
        
        if result_text.lower() == 'null':
            return None
        
        # Tentar fazer parse do JSON
        result = json.loads(result_text)
        
        # Validar resultado
        if not isinstance(result.get('amount'), (int, float)) or result['amount'] <= 0:
            return None
        
        if not result.get('description'):
            return None
        
        return result
    
    except Exception as e:
        logger.error(f"Erro na extração com IA: {str(e)}")
        return None

def categorize_expense_with_ai(description: str) -> str:
    """
    Usar IA para categorizar um gasto baseado na descrição
    """
    try:
        client = openai.OpenAI()
        
        prompt = f"""
        Categorize o seguinte gasto em uma das categorias:
        - Alimentação
        - Transporte  
        - Saúde
        - Lazer
        - Casa
        - Roupas
        - Outros
        
        Descrição: "{description}"
        
        Responda apenas com o nome da categoria.
        """
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Você categoriza gastos em português brasileiro."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=20,
            temperature=0.1
        )
        
        category = response.choices[0].message.content.strip()
        
        # Validar categoria
        valid_categories = ['Alimentação', 'Transporte', 'Saúde', 'Lazer', 'Casa', 'Roupas', 'Outros']
        if category in valid_categories:
            return category
        else:
            return 'Outros'
    
    except Exception as e:
        logger.error(f"Erro na categorização: {str(e)}")
        return 'Outros'

