import requests
import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Configurações do WhatsApp Business API
WHATSAPP_ACCESS_TOKEN = os.getenv('WHATSAPP_ACCESS_TOKEN', 'seu_token_aqui')
WHATSAPP_PHONE_NUMBER_ID = os.getenv('WHATSAPP_PHONE_NUMBER_ID', 'seu_phone_number_id')
WHATSAPP_API_VERSION = 'v18.0'

def send_whatsapp_message(to_number: str, message: str) -> bool:
    """
    Enviar mensagem de texto via WhatsApp Business API
    
    Args:
        to_number: Número do destinatário (formato internacional)
        message: Texto da mensagem
        
    Returns:
        True se enviado com sucesso, False caso contrário
    """
    try:
        url = f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/{WHATSAPP_PHONE_NUMBER_ID}/messages"
        
        headers = {
            'Authorization': f'Bearer {WHATSAPP_ACCESS_TOKEN}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'messaging_product': 'whatsapp',
            'to': to_number,
            'type': 'text',
            'text': {
                'body': message
            }
        }
        
        response = requests.post(url, json=data, headers=headers)
        
        if response.status_code == 200:
            logger.info(f"Mensagem enviada com sucesso para {to_number}")
            return True
        else:
            logger.error(f"Erro ao enviar mensagem: {response.status_code} - {response.text}")
            return False
    
    except Exception as e:
        logger.error(f"Erro ao enviar mensagem WhatsApp: {str(e)}")
        return False

def send_whatsapp_document(to_number: str, document_url: str, filename: str, caption: str = "") -> bool:
    """
    Enviar documento via WhatsApp Business API
    
    Args:
        to_number: Número do destinatário
        document_url: URL do documento
        filename: Nome do arquivo
        caption: Legenda opcional
        
    Returns:
        True se enviado com sucesso, False caso contrário
    """
    try:
        url = f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/{WHATSAPP_PHONE_NUMBER_ID}/messages"
        
        headers = {
            'Authorization': f'Bearer {WHATSAPP_ACCESS_TOKEN}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'messaging_product': 'whatsapp',
            'to': to_number,
            'type': 'document',
            'document': {
                'link': document_url,
                'filename': filename
            }
        }
        
        if caption:
            data['document']['caption'] = caption
        
        response = requests.post(url, json=data, headers=headers)
        
        if response.status_code == 200:
            logger.info(f"Documento enviado com sucesso para {to_number}")
            return True
        else:
            logger.error(f"Erro ao enviar documento: {response.status_code} - {response.text}")
            return False
    
    except Exception as e:
        logger.error(f"Erro ao enviar documento WhatsApp: {str(e)}")
        return False

def send_whatsapp_template_message(to_number: str, template_name: str, language_code: str = "pt_BR", components: list = None) -> bool:
    """
    Enviar mensagem template via WhatsApp Business API
    
    Args:
        to_number: Número do destinatário
        template_name: Nome do template aprovado
        language_code: Código do idioma
        components: Componentes do template
        
    Returns:
        True se enviado com sucesso, False caso contrário
    """
    try:
        url = f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/{WHATSAPP_PHONE_NUMBER_ID}/messages"
        
        headers = {
            'Authorization': f'Bearer {WHATSAPP_ACCESS_TOKEN}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'messaging_product': 'whatsapp',
            'to': to_number,
            'type': 'template',
            'template': {
                'name': template_name,
                'language': {
                    'code': language_code
                }
            }
        }
        
        if components:
            data['template']['components'] = components
        
        response = requests.post(url, json=data, headers=headers)
        
        if response.status_code == 200:
            logger.info(f"Template enviado com sucesso para {to_number}")
            return True
        else:
            logger.error(f"Erro ao enviar template: {response.status_code} - {response.text}")
            return False
    
    except Exception as e:
        logger.error(f"Erro ao enviar template WhatsApp: {str(e)}")
        return False

def mark_message_as_read(message_id: str) -> bool:
    """
    Marcar mensagem como lida
    
    Args:
        message_id: ID da mensagem
        
    Returns:
        True se marcado com sucesso, False caso contrário
    """
    try:
        url = f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/{WHATSAPP_PHONE_NUMBER_ID}/messages"
        
        headers = {
            'Authorization': f'Bearer {WHATSAPP_ACCESS_TOKEN}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'messaging_product': 'whatsapp',
            'status': 'read',
            'message_id': message_id
        }
        
        response = requests.post(url, json=data, headers=headers)
        
        if response.status_code == 200:
            logger.info(f"Mensagem {message_id} marcada como lida")
            return True
        else:
            logger.error(f"Erro ao marcar como lida: {response.status_code} - {response.text}")
            return False
    
    except Exception as e:
        logger.error(f"Erro ao marcar mensagem como lida: {str(e)}")
        return False

def get_whatsapp_media_url(media_id: str) -> Optional[str]:
    """
    Obter URL de mídia do WhatsApp
    
    Args:
        media_id: ID da mídia
        
    Returns:
        URL da mídia ou None se houver erro
    """
    try:
        url = f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/{media_id}"
        
        headers = {
            'Authorization': f'Bearer {WHATSAPP_ACCESS_TOKEN}'
        }
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            return data.get('url')
        else:
            logger.error(f"Erro ao obter URL da mídia: {response.status_code} - {response.text}")
            return None
    
    except Exception as e:
        logger.error(f"Erro ao obter URL da mídia: {str(e)}")
        return None

