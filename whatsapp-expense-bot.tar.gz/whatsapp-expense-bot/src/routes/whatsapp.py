from flask import Blueprint, request, jsonify
from src.models.expense import db, Expense
from src.services.ai_processor import process_expense_message
from src.services.whatsapp_client import send_whatsapp_message
import logging

whatsapp_bp = Blueprint('whatsapp', __name__)

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@whatsapp_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    """Verificação do webhook do WhatsApp"""
    verify_token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')
    
    # Token de verificação (deve ser configurado no Meta Developer Console)
    VERIFY_TOKEN = "meu_token_secreto_123"
    
    if verify_token == VERIFY_TOKEN:
        logger.info("Webhook verificado com sucesso")
        return challenge
    else:
        logger.error("Token de verificação inválido")
        return "Token inválido", 403

@whatsapp_bp.route('/webhook', methods=['POST'])
def handle_webhook():
    """Processar mensagens recebidas do WhatsApp"""
    try:
        data = request.get_json()
        logger.info(f"Webhook recebido: {data}")
        
        # Verificar se há mensagens na requisição
        if 'entry' in data:
            for entry in data['entry']:
                if 'changes' in entry:
                    for change in entry['changes']:
                        if change.get('field') == 'messages':
                            process_whatsapp_message(change['value'])
        
        return jsonify({"status": "success"}), 200
    
    except Exception as e:
        logger.error(f"Erro ao processar webhook: {str(e)}")
        return jsonify({"error": str(e)}), 500

def process_whatsapp_message(message_data):
    """Processar mensagem individual do WhatsApp"""
    try:
        if 'messages' not in message_data:
            return
        
        for message in message_data['messages']:
            # Extrair informações da mensagem
            from_number = message['from']
            message_id = message['id']
            
            # Processar diferentes tipos de mensagem
            if message['type'] == 'text':
                text_content = message['text']['body']
                process_text_expense(from_number, text_content)
            
            elif message['type'] == 'audio':
                audio_id = message['audio']['id']
                process_audio_expense(from_number, audio_id)
            
            # Marcar mensagem como lida
            mark_message_as_read(message_id)
    
    except Exception as e:
        logger.error(f"Erro ao processar mensagem: {str(e)}")

def process_text_expense(phone_number, text):
    """Processar gasto enviado via texto"""
    try:
        # Usar IA para extrair informações do gasto
        expense_data = process_expense_message(text)
        
        if expense_data:
            # Salvar no banco de dados
            expense = Expense(
                user_phone=phone_number,
                description=expense_data['description'],
                amount=expense_data['amount'],
                category=expense_data.get('category')
            )
            
            db.session.add(expense)
            db.session.commit()
            
            # Enviar confirmação
            confirmation_msg = f"✅ Gasto registrado!\n\n💰 Valor: R$ {expense_data['amount']:.2f}\n📝 Descrição: {expense_data['description']}"
            if expense_data.get('category'):
                confirmation_msg += f"\n🏷️ Categoria: {expense_data['category']}"
            
            send_whatsapp_message(phone_number, confirmation_msg)
        else:
            send_whatsapp_message(phone_number, "❌ Não consegui entender o gasto. Tente novamente com formato: 'Gastei R$ 50 no supermercado'")
    
    except Exception as e:
        logger.error(f"Erro ao processar gasto de texto: {str(e)}")
        send_whatsapp_message(phone_number, "❌ Erro ao processar seu gasto. Tente novamente.")

def process_audio_expense(phone_number, audio_id):
    """Processar gasto enviado via áudio"""
    try:
        # Baixar e transcrever áudio
        from src.services.audio_processor import transcribe_audio
        
        text = transcribe_audio(audio_id)
        if text:
            # Processar como texto
            process_text_expense(phone_number, text)
        else:
            send_whatsapp_message(phone_number, "❌ Não consegui entender o áudio. Tente enviar novamente.")
    
    except Exception as e:
        logger.error(f"Erro ao processar áudio: {str(e)}")
        send_whatsapp_message(phone_number, "❌ Erro ao processar áudio. Tente novamente.")

def mark_message_as_read(message_id):
    """Marcar mensagem como lida"""
    # Implementar chamada para API do WhatsApp para marcar como lida
    pass

@whatsapp_bp.route('/expenses/<phone_number>', methods=['GET'])
def get_user_expenses(phone_number):
    """Obter gastos de um usuário"""
    try:
        expenses = Expense.query.filter_by(user_phone=phone_number).order_by(Expense.date.desc()).all()
        return jsonify([expense.to_dict() for expense in expenses])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@whatsapp_bp.route('/expenses/export/<phone_number>', methods=['GET'])
def export_expenses(phone_number):
    """Exportar gastos para planilha"""
    try:
        from src.services.spreadsheet_generator import generate_expense_spreadsheet
        
        expenses = Expense.query.filter_by(user_phone=phone_number).order_by(Expense.date.desc()).all()
        spreadsheet_url = generate_expense_spreadsheet(expenses, phone_number)
        
        return jsonify({"spreadsheet_url": spreadsheet_url})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

