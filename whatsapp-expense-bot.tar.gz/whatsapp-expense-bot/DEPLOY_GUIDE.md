# 🚀 Guia Completo de Deploy - WhatsApp Expense Bot

## Visão Geral

Este guia fornece instruções detalhadas para fazer o deploy do WhatsApp Expense Bot em diferentes ambientes, desde desenvolvimento local até produção em nuvem.

## 📋 Pré-requisitos

### Requisitos do Sistema
- **Python**: 3.11 ou superior
- **Memória RAM**: Mínimo 512MB, recomendado 1GB
- **Espaço em Disco**: Mínimo 1GB livre
- **Sistema Operacional**: Linux (Ubuntu 20.04+), macOS, Windows

### Contas e Serviços Necessários
1. **Meta for Developers**: Para WhatsApp Business API
2. **OpenAI**: Para processamento de IA (já configurado)
3. **Servidor/Hosting**: Para deploy em produção

## 🔧 Configuração do WhatsApp Business API

### Passo 1: Criar Aplicação no Meta for Developers

1. Acesse [Meta for Developers](https://developers.facebook.com/)
2. Clique em "Meus Apps" → "Criar App"
3. Selecione "Negócios" como tipo de app
4. Preencha as informações:
   - **Nome do App**: WhatsApp Expense Bot
   - **Email de Contato**: seu-email@exemplo.com
   - **Categoria**: Produtividade

### Passo 2: Adicionar WhatsApp Business

1. No painel do app, clique em "Adicionar Produto"
2. Selecione "WhatsApp Business"
3. Clique em "Configurar"

### Passo 3: Configurar Número de Telefone

1. Na seção "API Setup", você verá:
   - **Temporary access token**: Copie este token
   - **Phone number ID**: Copie este ID
   - **WhatsApp Business Account ID**: Anote este ID

2. Teste o envio de mensagem usando a ferramenta de teste

### Passo 4: Configurar Webhook

1. Na seção "Configuration", clique em "Edit"
2. Configure:
   - **Callback URL**: `https://seu-dominio.com/api/whatsapp/webhook`
   - **Verify Token**: `meu_token_secreto_123` (ou outro valor secreto)
   - **Webhook Fields**: Marque `messages`

3. Clique em "Verify and Save"

## 🏠 Deploy Local (Desenvolvimento)

### Passo 1: Preparar Ambiente

```bash
# Clonar o projeto
git clone <repository-url>
cd whatsapp-expense-bot

# Criar ambiente virtual
python3.11 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instalar dependências
pip install -r requirements.txt
```

### Passo 2: Configurar Variáveis de Ambiente

```bash
# Copiar arquivo de exemplo
cp .env.example .env

# Editar .env com suas configurações
nano .env
```

Configurar no arquivo `.env`:
```env
WHATSAPP_ACCESS_TOKEN=seu_token_temporario_aqui
WHATSAPP_PHONE_NUMBER_ID=seu_phone_number_id
WHATSAPP_VERIFY_TOKEN=meu_token_secreto_123
```

### Passo 3: Executar Aplicação

```bash
# Executar em modo desenvolvimento
python src/main.py

# Ou usar o script de deploy
./deploy.sh
```

A aplicação estará disponível em `http://localhost:5001`

### Passo 4: Testar Webhook (Desenvolvimento)

Para testar localmente, use ngrok ou similar:

```bash
# Instalar ngrok
npm install -g ngrok

# Expor porta local
ngrok http 5001

# Use a URL gerada no webhook do Meta
```

## 🌐 Deploy em Produção

### Opção 1: VPS/Servidor Dedicado

#### Passo 1: Preparar Servidor

```bash
# Atualizar sistema (Ubuntu)
sudo apt update && sudo apt upgrade -y

# Instalar dependências
sudo apt install python3.11 python3.11-venv nginx certbot python3-certbot-nginx

# Criar usuário para aplicação
sudo useradd -m -s /bin/bash whatsapp-bot
sudo su - whatsapp-bot
```

#### Passo 2: Deploy da Aplicação

```bash
# Clonar projeto
git clone <repository-url>
cd whatsapp-expense-bot

# Configurar ambiente
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn

# Configurar variáveis de ambiente
cp .env.example .env
nano .env  # Configurar com valores de produção
```

#### Passo 3: Configurar Gunicorn

Criar arquivo `gunicorn.conf.py`:
```python
bind = "127.0.0.1:5000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 120
keepalive = 2
max_requests = 1000
max_requests_jitter = 100
preload_app = True
```

#### Passo 4: Criar Serviço Systemd

Criar `/etc/systemd/system/whatsapp-bot.service`:
```ini
[Unit]
Description=WhatsApp Expense Bot
After=network.target

[Service]
User=whatsapp-bot
Group=whatsapp-bot
WorkingDirectory=/home/whatsapp-bot/whatsapp-expense-bot
Environment=PATH=/home/whatsapp-bot/whatsapp-expense-bot/venv/bin
ExecStart=/home/whatsapp-bot/whatsapp-expense-bot/venv/bin/gunicorn -c gunicorn.conf.py src.main:app
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
# Habilitar e iniciar serviço
sudo systemctl enable whatsapp-bot
sudo systemctl start whatsapp-bot
sudo systemctl status whatsapp-bot
```

#### Passo 5: Configurar Nginx

Criar `/etc/nginx/sites-available/whatsapp-bot`:
```nginx
server {
    listen 80;
    server_name seu-dominio.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
# Habilitar site
sudo ln -s /etc/nginx/sites-available/whatsapp-bot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Configurar SSL
sudo certbot --nginx -d seu-dominio.com
```

### Opção 2: Docker

#### Dockerfile
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Instalar dependências do sistema
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copiar arquivos
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

# Criar usuário não-root
RUN useradd -m -u 1000 appuser && chown -R appuser:appuser /app
USER appuser

EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "src.main:app"]
```

#### docker-compose.yml
```yaml
version: '3.8'

services:
  whatsapp-bot:
    build: .
    ports:
      - "5000:5000"
    environment:
      - WHATSAPP_ACCESS_TOKEN=${WHATSAPP_ACCESS_TOKEN}
      - WHATSAPP_PHONE_NUMBER_ID=${WHATSAPP_PHONE_NUMBER_ID}
      - WHATSAPP_VERIFY_TOKEN=${WHATSAPP_VERIFY_TOKEN}
    volumes:
      - ./data:/app/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - whatsapp-bot
    restart: unless-stopped
```

```bash
# Deploy com Docker
docker-compose up -d
```

### Opção 3: Plataformas de Nuvem

#### Heroku
```bash
# Instalar Heroku CLI
# Criar Procfile
echo "web: gunicorn src.main:app" > Procfile

# Deploy
heroku create whatsapp-expense-bot
heroku config:set WHATSAPP_ACCESS_TOKEN=seu_token
heroku config:set WHATSAPP_PHONE_NUMBER_ID=seu_id
git push heroku main
```

#### Railway
```bash
# Instalar Railway CLI
npm install -g @railway/cli

# Deploy
railway login
railway init
railway up
```

## 🔒 Configurações de Segurança

### SSL/TLS
- **Obrigatório** para webhook do WhatsApp
- Use Let's Encrypt para certificados gratuitos
- Configure redirecionamento HTTP → HTTPS

### Firewall
```bash
# Ubuntu UFW
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

### Backup
```bash
# Script de backup automático
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
tar -czf backup_$DATE.tar.gz src/database/app.db logs/
```

## 📊 Monitoramento

### Logs
```bash
# Logs da aplicação
tail -f logs/app.log

# Logs do sistema
sudo journalctl -u whatsapp-bot -f

# Logs do Nginx
sudo tail -f /var/log/nginx/access.log
```

### Métricas
- CPU e memória do servidor
- Tempo de resposta da API
- Taxa de sucesso do webhook
- Número de mensagens processadas

## 🔧 Manutenção

### Atualizações
```bash
# Backup antes da atualização
./backup.sh

# Atualizar código
git pull origin main

# Atualizar dependências
pip install -r requirements.txt

# Reiniciar serviço
sudo systemctl restart whatsapp-bot
```

### Troubleshooting

#### Webhook não funciona
1. Verificar URL e certificado SSL
2. Confirmar verify token
3. Checar logs de erro
4. Testar endpoint manualmente

#### IA não processa mensagens
1. Verificar API key do OpenAI
2. Confirmar conectividade
3. Verificar formato das mensagens
4. Checar logs de processamento

#### Banco de dados corrompido
1. Parar aplicação
2. Restaurar backup
3. Verificar integridade
4. Reiniciar aplicação

## 📞 Suporte

### Recursos de Ajuda
- **Documentação**: README.md
- **Logs**: logs/app.log
- **Status**: /health endpoint
- **Testes**: pytest tests/

### Contato
- GitHub Issues para bugs
- Documentação da API do WhatsApp
- Suporte do OpenAI

---

**Sucesso no seu deploy! 🚀**

